//import coordinators.CliCoordinator;
import coordinators.GuiCoordinator;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {
        GuiCoordinator.main(args);
    }
}
