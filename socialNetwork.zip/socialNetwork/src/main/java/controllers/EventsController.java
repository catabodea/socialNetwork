package controllers;

import domain.entities.Event;
import domain.entities.User;
import domain.exceptions.ValidationException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import services.SocialNetworkService;
import utils.MainEvent;
import utils.Observer;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class EventsController implements Observer<MainEvent> {
    SocialNetworkService service;
    ObservableList<Event> model = FXCollections.observableArrayList();
    Stage stage;
    User user;

    @FXML
    TextField nameField;
    @FXML
    TextField descriptionField;
    @FXML
    DatePicker datePicker;
    @FXML
    ListView<Event> eventList;
    @FXML
    RadioButton showMyEvents;
    @FXML
    ListView<String> notificationList;

    @FXML
    public void initialize() {
        eventList.setItems(model);
    }

    public void setService(SocialNetworkService service, Stage stage, User user) throws SQLException, InterruptedException {
        this.service = service;
        service.addObserver(this);
        this.user=user;
        this.stage = stage;
        initEvent();
        showNotifications();
    }

    private void initEvent() throws SQLException {
        List<Event> events;
        Predicate<Event> predicate;

        if (!showMyEvents.isSelected()) {
            predicate = event -> event.getDate().isAfter(LocalDate.now());
        }
        else {
            predicate = event -> event.getDate().isAfter(LocalDate.now()) && event.getParticipants().stream().anyMatch(e -> e.getUser().getId().equals(user.getId()));
        }
        events = service.getEvents().stream()
                .filter(predicate)
                .collect(Collectors.toList());
        model.setAll(events);

    }

    @Override
    public void update(MainEvent event) throws SQLException {
        initEvent();
    }


    public void handleParticipateButton(ActionEvent actionEvent) {
        if (eventList.getSelectionModel().isEmpty()) {
            MessageAlert.showErrorMessage(null, "Please select an event.");
            return;
        }
        try {
            Event e = eventList.getSelectionModel().getSelectedItem();
            if (service.getEvents().stream().anyMatch(ev -> ev.getParticipants().stream().anyMatch(p -> p.getUser().getId().equals(user.getId()) && p.getEventId().equals(e.getId())))) {
                MessageAlert.showErrorMessage(null,"You are already a participant in this event.");
                return;
            }
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
            notificationList.getItems().add(0, LocalDateTime.now().format(formatter) + " " + e.getTitle() + " " + e.getDescription() + " in " + Period.between(LocalDate.now(), e.getDate()).getDays() + " days");
            service.addParticipant(user.getId(), e);
            MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "Event", "You have been added to this event.");
        } catch (ValidationException | SQLException e) {
            MessageAlert.showErrorMessage(null, e.getMessage());
        }
    }

    public void handleEventNoNotifications(ActionEvent actionEvent) {
        if (eventList.getSelectionModel().isEmpty()) {
            MessageAlert.showErrorMessage(null, "Please select an event.");
            return;
        }
        try {
            Event e = eventList.getSelectionModel().getSelectedItem();
            service.dismissNotifications(e,user.getId());
            MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "Event", "Notifications have been turned off.");
        } catch (ValidationException | SQLException e) {
            MessageAlert.showErrorMessage(null, e.getMessage());
        }
    }

    public void handleCreateButton(ActionEvent actionEvent) {
        if (nameField.getText().equals("") || descriptionField.getText().equals("") || datePicker.getValue() == null) {
            MessageAlert.showErrorMessage(null, "Make sure all the fields are filled.");
            return;
        }
        try {
            service.addEvent(nameField.getText(), descriptionField.getText(), datePicker.getValue());
            MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "Event", "Event successfully created.");
            nameField.clear();
            descriptionField.clear();
        } catch (ValidationException | SQLException e) {
            MessageAlert.showErrorMessage(null, e.getMessage());
        }
    }

    public void handleMyEvents(ActionEvent actionEvent) throws SQLException {
        initEvent();
    }

    public void showNotifications() throws InterruptedException, SQLException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        service.getNotificationsFor(user.getId()).forEach(notif -> notificationList.getItems().add(0, LocalDateTime.now().format(formatter) + " " + notif));
    }
}
