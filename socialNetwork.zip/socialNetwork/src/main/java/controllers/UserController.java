package controllers;

import domain.entities.Message;
import domain.entities.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import repositories.paging.Page;
import services.SocialNetworkService;
import utils.MainEvent;
import utils.Observer;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class UserController implements Observer<MainEvent> {
    SocialNetworkService service;
    ObservableList<User> masterModel = FXCollections.observableArrayList();
    ObservableList<Message> detailsModel = FXCollections.observableArrayList();
    Stage primaryStage;
    Scene loginScene;

    private User user;

    @FXML
    TableView<User> masterView;
    @FXML
    TableView<Message> detailsView;
    @FXML
    TableColumn<User,String> columnUserName;
    @FXML
    TableColumn<User,String> columnFirstName;
    @FXML
    TableColumn<User,String> columnLastName;
    @FXML
    TableColumn<Message,String> columnFrom;
    @FXML
    TableColumn<Message,String> columnText;
    @FXML
    TableColumn<Message,String> columnDate;
    @FXML
    TextField textMessageField;
    @FXML
    Pagination messagePaginator;

    public void setUser(User user) {
        this.user = user;
    }

    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("Social Network App");
    }

    public void setLoginScene(Scene scene) {
        this.loginScene = scene;
    }

    public void setSocialNetworkService(SocialNetworkService service) throws SQLException {
        this.service = service;
        service.addObserver(this);
        initMasterModel();
    }

    @FXML
    public void initialize() {
        columnUserName.setCellValueFactory(new PropertyValueFactory<User, String>("userName"));
        columnFirstName.setCellValueFactory(new PropertyValueFactory<User, String>("firstName"));
        columnLastName.setCellValueFactory(new PropertyValueFactory<User, String>("lastName"));
        masterView.setItems(masterModel);
        masterView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                initDetailsModel();
            }
        });
        columnFrom.setCellValueFactory(new PropertyValueFactory<Message, String>("fromName"));
        columnText.setCellValueFactory(new PropertyValueFactory<Message, String>("text"));
        columnDate.setCellValueFactory(new PropertyValueFactory<Message, String>("date"));
        detailsView.setItems(detailsModel);
    }

    private void initMasterModel() {
        Iterable<User> users = null;
        try {
            users = service.getUserFriends(user.getId());
        }
        catch (SQLException exception) {
            exception.printStackTrace();
        }
        List<User> friendList = StreamSupport.stream(Objects.requireNonNull(users).spliterator(), false).collect(Collectors.toList());
        masterModel.setAll(friendList);
    }
    public void pageHandler(){
        initDetailsModel();
        detailsView.setItems(detailsModel);
    }
    private void initDetailsModel() {
        List<Message> messages = null;
        User selected = masterView.getSelectionModel().getSelectedItem();
        if (selected != null) {
            try {
                messagePaginator.currentPageIndexProperty().addListener((obs, oldIndex, newIndex) ->{
                            pageHandler();
                        }
                );
                Page<Message> users = service.getMessagesOnPage(messagePaginator.getCurrentPageIndex(), user.getId(), selected.getId());
                if(users!=null)
                    detailsModel.setAll(users.getContent().collect(Collectors.toList()));
            }
            catch (SQLException exception) {
                exception.printStackTrace();
            }

        }
    }

    @Override
    public void update(MainEvent event) {
        initMasterModel();
        initDetailsModel();
    }

    @FXML
    public void handleAddFriend(ActionEvent event) {
        showAddDialog();
    }

    public void showAddDialog() {
        try {
            FXMLLoader dialogLoader = new FXMLLoader();
            dialogLoader.setLocation(getClass().getResource("/views/saveDialogView.fxml"));
            AnchorPane dialogLayout = dialogLoader.load();
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Send Friend Request");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene dialogScene = new Scene(dialogLayout);
            dialogStage.setScene(dialogScene);
            EditDialogController dialogController = dialogLoader.getController();
            dialogController.setService(service, dialogStage, user);
            dialogStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void handleRemoveFriend(ActionEvent actionEvent) throws SQLException {
        User friend = masterView.getSelectionModel().getSelectedItem();
        if (friend != null) {
            if (service.deleteFriendship(user.getId(), friend.getId()).isEmpty()) {
                MessageAlert.showWarningMessage(null, "Please select an user.");
            }
            else {
                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,"Removed Friend","Removed " + friend.getUserName() + " from your friend list.");
            }
        }
        else {
            MessageAlert.showWarningMessage(null, "Please select an user.");
        }
    }

    @FXML
    public void handleLogOut(ActionEvent event) {
        primaryStage.setScene(loginScene);
    }

    @FXML
    public void handleShowRequests(ActionEvent event) {
        showRequestsDialog();
    }

    public void showRequestsDialog() {
        try {
            FXMLLoader dialogLoader = new FXMLLoader();
            dialogLoader.setLocation(getClass().getResource("/views/requestsDialogView.fxml"));
            AnchorPane dialogLayout = dialogLoader.load();
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Friend Requests");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene dialogScene = new Scene(dialogLayout);
            dialogStage.setScene(dialogScene);
            RequestsDialogController dialogController = dialogLoader.getController();
            dialogController.setService(service, dialogStage, user);
            dialogStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void handleGroupMessage(ActionEvent event) {
        showGroupMessageDialog();
    }

    private void showGroupMessageDialog() {
        try {
            FXMLLoader dialogLoader = new FXMLLoader();
            dialogLoader.setLocation(getClass().getResource("/views/messageDialogView.fxml"));
            AnchorPane dialogLayout = dialogLoader.load();
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Group message");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene dialogScene = new Scene(dialogLayout);
            dialogStage.setScene(dialogScene);
            MessageDialogController dialogController = dialogLoader.getController();
            dialogController.setService(service, dialogStage, user);
            dialogStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void handleActivityButton(ActionEvent event) {
        showActivityWindow();
    }

    private void showActivityWindow() {
        try {
            FXMLLoader activityLoader = new FXMLLoader();
            activityLoader.setLocation(getClass().getResource("/views/activityView.fxml"));
            AnchorPane activityLayout = activityLoader.load();
            Stage activityStage = new Stage();
            activityStage.setTitle("User activity");
            activityStage.initModality(Modality.WINDOW_MODAL);
            activityStage.initOwner(primaryStage);
            Scene activityScene = new Scene(activityLayout);
            activityStage.setScene(activityScene);
            ActivityController activityController = activityLoader.getController();
            activityController.setService(service, activityStage, user);
            activityStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void handleChatWindow(ActionEvent event) {
        showChatWindow();
    }

    private void showChatWindow() {
        if (!masterView.getSelectionModel().isEmpty()) {
            User friend = masterView.getSelectionModel().getSelectedItem();
            try {
                FXMLLoader chatLoader = new FXMLLoader();
                chatLoader.setLocation(getClass().getResource("/views/chatView.fxml"));
                AnchorPane chatLayout = chatLoader.load();
                Stage chatStage = new Stage();
                chatStage.setTitle("Chat");
                chatStage.initModality(Modality.WINDOW_MODAL);
                chatStage.initOwner(primaryStage);
                Scene chatScene = new Scene(chatLayout);
                chatStage.setScene(chatScene);
                ChatController chatController = chatLoader.getController();
                chatController.setService(service, chatStage, friend, user);
                chatStage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else {
            MessageAlert.showErrorMessage(null, "Please select a user.");
        }
    }

    public void handleSendMessage(ActionEvent event) throws SQLException {
        if (!textMessageField.getText().equals("")) {
            if (!masterView.getSelectionModel().isEmpty()) {
                List<Long> selected = new ArrayList<>();
                selected.add(masterView.getSelectionModel().getSelectedItem().getId());
                service.sendMessage(user.getId(), selected, textMessageField.getText());
                textMessageField.clear();
            }
            else {
                MessageAlert.showErrorMessage(null, "Please select a user.");
            }
        }
    }

    public void handleReplyMessage(ActionEvent event) throws SQLException {
        if (!textMessageField.getText().equals("") && !masterView.getSelectionModel().isEmpty() && !detailsView.getSelectionModel().isEmpty()) {
            Message message = detailsView.getSelectionModel().getSelectedItem();
            if (message.getFrom().getId().equals(user.getId())) {
                MessageAlert.showWarningMessage(null, "You can't reply to your own message.");
            }
            service.sendReply(message.getId(), user.getId(), textMessageField.getText() + " reply");
            textMessageField.clear();
        }
        else {
            MessageAlert.showWarningMessage(null, "Please select a message to reply to.");
        }
    }

    public void handleEventButton(ActionEvent actionEvent) {
        try {
            FXMLLoader dialogLoader = new FXMLLoader();
            dialogLoader.setLocation(getClass().getResource("/views/eventsView.fxml"));
            AnchorPane dialogLayout = dialogLoader.load();
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Events");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene dialogScene = new Scene(dialogLayout);
            dialogStage.setScene(dialogScene);
            EventsController dialogController = dialogLoader.getController();
            dialogController.setService(service, dialogStage, user);
            dialogStage.show();
        } catch (IOException | SQLException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
