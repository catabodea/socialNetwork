package controllers;

import com.google.common.hash.Hashing;
import domain.entities.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import services.SocialNetworkService;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.Optional;

public class LoginController {
    SocialNetworkService service;
    Stage primaryStage;
    Scene scene;

    @FXML
    TextField usernameField;
    @FXML
    PasswordField passwordField;

    @FXML
    public void initialize() {
        usernameField.setPromptText("username");
        passwordField.setPromptText("password");
    }

    public void setSocialNetworkService(SocialNetworkService service) {
        this.service = service;
    }

    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    public void setScene(Scene scene) {
        this.scene = scene;
    }

    private void changeScene(User user) {
        FXMLLoader userLoader = new FXMLLoader();
        userLoader.setLocation(getClass().getResource("/views/userView.fxml"));
        AnchorPane userLayout = null;
        try {
            userLayout = userLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        primaryStage.setScene(new Scene(userLayout));
        UserController controller = userLoader.getController();
        try {
            controller.setUser(user);
            controller.setPrimaryStage(primaryStage);
            controller.setLoginScene(this.scene);
            controller.setSocialNetworkService(service);
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
    }

    @FXML
    public void handleLogIn(ActionEvent actionEvent) throws SQLException {
        Optional<User> user = service.getUserByUserName(usernameField.getText());
        if (user.isEmpty()) {
            usernameField.clear();
            passwordField.clear();
            usernameField.setPromptText("username");
            passwordField.setPromptText("password");
            MessageAlert.showErrorMessage(null, "User not found.");
        }

        else {
            String hash = Hashing.sha256()
                    .hashString(passwordField.getText(), StandardCharsets.UTF_8)
                    .toString();

            if (user.get().getPassword().equals(hash)) {
                usernameField.clear();
                passwordField.clear();
                changeScene(user.get());
            }
            else {
                passwordField.clear();
                passwordField.setPromptText("password");
                MessageAlert.showErrorMessage(null, "Incorrect password.");
            }
        }
    }
}
