package controllers;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import domain.entities.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import services.SocialNetworkService;
import utils.MainEvent;
import utils.Observer;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

public class ActivityController implements Observer<MainEvent> {
    SocialNetworkService service;
    ObservableList<String> model = FXCollections.observableArrayList();
    Stage stage;
    User user;

    @FXML
    ListView<String> activityView;
    @FXML
    DatePicker fromDatePicker;
    @FXML
    DatePicker toDatePicker;
    @FXML
    Button backButton;

    @FXML
    public void initialize() {
        activityView.setItems(model);
    }

    public void setService(SocialNetworkService service, Stage stage, User user) {
        this.service = service;
        service.addObserver(this);
        this.stage = stage;
        this.user = user;
        fromDatePicker.setValue(LocalDate.now());
        toDatePicker.setValue(LocalDate.now());
        initActivity();
    }

    private void initActivity() {
        List<String> activity = null;
        try {
            LocalDateTime from = fromDatePicker.getValue().atStartOfDay();
            LocalDateTime to = toDatePicker.getValue().atTime(LocalTime.MAX);
            activity = service.getActivityFromPeriod(user.getId(), from, to);
        }
        catch (SQLException exception) {
            exception.printStackTrace();
        }
        model.setAll(activity);
    }

    @Override
    public void update(MainEvent event) throws SQLException {
        initActivity();
    }

    @FXML
    public void handlePeriodChanged(ActionEvent actionEvent) {
        initActivity();
    }

    @FXML
    public void handleSave(ActionEvent actionEvent) throws FileNotFoundException, DocumentException {
        Document document = new Document();
        PdfWriter.getInstance(document, new FileOutputStream("E:\\Laburi MAP\\socialNetwork\\data\\activity.pdf"));
        document.open();
        document.addTitle(user.getFirstName() + " " + user.getLastName() + "'s activity");
        Paragraph text = new Paragraph();
        text.add(new Paragraph("\n"));
        text.add(new Paragraph(user.getFirstName() + " " + user.getLastName() + "'s activity"));
        text.add(new Paragraph("\n"));
        for (String line : model) {
            text.add(new Paragraph(line));
        }
        document.add(text);
        document.close();
    }

    @FXML
    public void handleBackButton(ActionEvent actionEvent) {
        stage.close();
    }
}
