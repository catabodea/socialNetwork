package controllers;

import domain.Status;
import domain.entities.FriendRequest;
import domain.entities.User;
import domain.exceptions.ValidationException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import services.SocialNetworkService;
import utils.MainEvent;
import utils.Observer;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class RequestsDialogController implements Observer<MainEvent> {
    SocialNetworkService service;
    ObservableList<FriendRequest> model = FXCollections.observableArrayList();
    Stage stage;
    User user;

    @FXML
    TableColumn<FriendRequest,String> columnFromName;
    @FXML
    TableColumn<FriendRequest,String> columnToName;
    @FXML
    TableColumn<FriendRequest, String> columnStatus;
    @FXML
    TableColumn<FriendRequest, String> columnDate;
    @FXML
    TableView<FriendRequest> masterView;

    @FXML
    public void initialize() {
        columnFromName.setCellValueFactory(new PropertyValueFactory<FriendRequest, String>("fromName"));
        columnToName.setCellValueFactory(new PropertyValueFactory<FriendRequest, String>("toName"));
        columnStatus.setCellValueFactory(new PropertyValueFactory<FriendRequest, String>("status"));
        columnDate.setCellValueFactory(new PropertyValueFactory<FriendRequest, String>("date"));
        masterView.setItems(model);
    }

    private void initModel() {
        List<FriendRequest> requests = null;
        try {
            requests = service.getFriendRequests().stream()
                    .filter(request -> request.getTo().getId().equals(user.getId()) || request.getFrom().getId().equals(user.getId()))
                    .collect(Collectors.toList());
        }
        catch (SQLException exception) {
            exception.printStackTrace();
        }
        model.setAll(requests);
    }

    @Override
    public void update(MainEvent event) throws SQLException {
        initModel();
    }

    public void setService(SocialNetworkService service, Stage stage, User user) {
        this.service = service;
        service.addObserver(this);
        this.stage = stage;
        this.user = user;
        initModel();
    }

    @FXML
    public void handleAcceptRequest(ActionEvent actionEvent) {
        if (masterView.getSelectionModel().isEmpty()) {
            MessageAlert.showErrorMessage(null, "Please select a request.");
            return;
        }
        try {
            FriendRequest request = masterView.getSelectionModel().getSelectedItem();
            if (user.getId().equals(request.getTo().getId())) {
                Optional<FriendRequest> optional = service.setFriendRequestStatus(request.getFrom().getId(), request.getTo().getId(), Status.APPROVED);
                if (optional.isEmpty()) {
                    MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "Friend Request", "Friend request accepted!");
                    stage.close();
                }
            }
            else {
                MessageAlert.showWarningMessage(null, "This friend request sent by you.");
            }
        } catch (ValidationException | SQLException e) {
            MessageAlert.showErrorMessage(null, e.getMessage());
        }
    }

    @FXML
    public void handleDenyRequest(ActionEvent actionEvent) {
        if (masterView.getSelectionModel().isEmpty()) {
            MessageAlert.showErrorMessage(null, "Please select a request.");
            return;
        }
        try {
            FriendRequest request = masterView.getSelectionModel().getSelectedItem();
            if (user.getId().equals(request.getTo().getId())) {
                Optional<FriendRequest> optional = service.setFriendRequestStatus(request.getFrom().getId(), request.getTo().getId(), Status.REJECTED);
                if (optional.isEmpty()) {
                    MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,"Friend Request","Friend request denied!");
                    stage.close();
                }
            }
            else {
                MessageAlert.showWarningMessage(null, "This friend request sent by you.");
            }
        } catch (ValidationException | SQLException e) {
            MessageAlert.showErrorMessage(null, e.getMessage());
        }
    }

    @FXML
    public void handleCancelRequest(ActionEvent actionEvent) {
        if (masterView.getSelectionModel().isEmpty()) {
            MessageAlert.showErrorMessage(null, "Please select a request.");
            return;
        }
        try {
            FriendRequest request = masterView.getSelectionModel().getSelectedItem();
            if (!request.getStatus().equals("PENDING")) {
                MessageAlert.showErrorMessage(null,"The user has already responded to this request.");
                return;
            }
            Optional<FriendRequest> optional = service.deleteFriendRequest(request.getFrom().getId(), request.getTo().getId());
            if (optional.isPresent()) {
                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "Friend Request", "Friend request cancelled.");
                stage.close();
            }
            else {
                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,"Friend Request","This friend request was not sent by you.");
            }
        } catch (ValidationException | SQLException e) {
            MessageAlert.showErrorMessage(null, e.getMessage());
        }
    }

    @FXML
    public void handleBackButton(ActionEvent actionEvent) {
        stage.close();
    }
}
