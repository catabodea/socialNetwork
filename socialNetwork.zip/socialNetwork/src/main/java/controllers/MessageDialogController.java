package controllers;

import domain.entities.Entity;
import domain.entities.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import services.SocialNetworkService;
import utils.MainEvent;
import utils.Observer;

import java.sql.SQLException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class MessageDialogController implements Observer<MainEvent> {
    SocialNetworkService service;
    ObservableList<User> masterModel = FXCollections.observableArrayList();
    Stage stage;
    User user;

    @FXML
    TableColumn<User,String> columnFirstName;
    @FXML
    TableColumn<User,String> columnLastName;
    @FXML
    TableView<User> masterView;
    @FXML
    TextField textMessageField;

    @FXML
    public void initialize() {
        columnFirstName.setCellValueFactory(new PropertyValueFactory<User, String>("firstName"));
        columnLastName.setCellValueFactory(new PropertyValueFactory<User, String>("lastName"));
        masterView.setItems(masterModel);
        masterView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    private void initModel() {
        Iterable<User> users = null;
        try {
            users = service.getUserFriends(user.getId());
        }
        catch (SQLException exception) {
            exception.printStackTrace();
        }
        List<User> friendList = StreamSupport.stream(Objects.requireNonNull(users).spliterator(), false).collect(Collectors.toList());
        masterModel.setAll(friendList);
    }

    @Override
    public void update(MainEvent event) {
        initModel();
    }

    public void setService(SocialNetworkService service, Stage stage, User user) {
        this.service = service;
        service.addObserver(this);
        this.stage = stage;
        this.user = user;
        initModel();
    }

    @FXML
    public void handleSendMessage(ActionEvent actionEvent) throws SQLException {
        if (masterView.getSelectionModel().getSelectedItems().isEmpty()) {
            MessageAlert.showErrorMessage(null,"Please select users.");
            return;
        }
        List<Long> friends = masterView.getSelectionModel().getSelectedItems().stream()
                .map(Entity::getId)
                .collect(Collectors.toList());
        if (!textMessageField.getText().equals("")) {
            service.sendMessage(user.getId(), friends, textMessageField.getText());
            MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,"Sent group message","Message successfully sent.");
            stage.close();
        }
        else {
            MessageAlert.showErrorMessage(null,"Please enter text.");
        }
    }

    @FXML
    public void handleBackButton(ActionEvent actionEvent) {
        stage.close();
    }
}
