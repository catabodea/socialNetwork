package controllers;

import domain.entities.FriendRequest;
import domain.entities.User;
import domain.exceptions.ValidationException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import services.SocialNetworkService;
import utils.MainEvent;
import utils.Observer;

import javafx.scene.control.TextField;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class EditDialogController implements Observer<MainEvent> {
    SocialNetworkService service;
    ObservableList<User> model = FXCollections.observableArrayList();
    Stage stage;
    User user;

    @FXML
    TextField searchField;
    @FXML
    TableColumn<User, String> columnUserName;
    @FXML
    TableColumn<User,String> columnFirstName;
    @FXML
    TableColumn<User,String> columnLastName;
    @FXML
    TableView<User> masterView;

    @FXML
    public void initialize() {
        columnUserName.setCellValueFactory(new PropertyValueFactory<User, String>("userName"));
        columnFirstName.setCellValueFactory(new PropertyValueFactory<User, String>("firstName"));
        columnLastName.setCellValueFactory(new PropertyValueFactory<User, String>("lastName"));
        masterView.setItems(model);
    }

    private void initModel() {
        List<User> users = null;
        try {
            List<User> friends = service.getUserFriends(user.getId());
            users = service.getUsers().stream()
                    .filter(entity -> !friends.contains(entity) && !user.getId().equals(entity.getId()) &&
                                (entity.getFirstName().contains(searchField.getText()) || entity.getLastName().contains(searchField.getText())))
                    .collect(Collectors.toList());
        }
        catch (SQLException exception) {
            exception.printStackTrace();
        }
        model.setAll(users);
    }

    @Override
    public void update(MainEvent event) throws SQLException {
        initModel();
    }

    public void setService(SocialNetworkService service, Stage stage, User user) {
        this.service = service;
        service.addObserver(this);
        this.stage = stage;
        this.user = user;
    }

    @FXML
    public void handleSaveRequest(ActionEvent event) {
        if (masterView.getSelectionModel().isEmpty()) {
            MessageAlert.showErrorMessage(null, "Please select a user.");
            return;
        }
        try {
            User to = masterView.getSelectionModel().getSelectedItem();
            Optional<FriendRequest> optional = service.addFriendRequest(user.getId(), to.getId());
            if (optional.isEmpty())
                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,"Friend Request","Friend request sent!");
        } catch (ValidationException | SQLException e) {
            MessageAlert.showErrorMessage(null, e.getMessage());
        }
    }

    @FXML
    public void handleCancelDialog(ActionEvent event) {
        stage.close();
    }

    @FXML
    public void handleUpdateMaster(KeyEvent event) {
        if (searchField == null || searchField.getText().equals("")) {
            model.clear();
        }
        else {
            initModel();
        }
    }
}
