package repositories;

import domain.User;
import domain.validators.ValidationException;

import java.util.*;

public interface UserRepository extends Repository<Long, User> {
    void addFriendship(Long firstId, Long secondId);

    void removeFriendship(Long firstId, Long secondId);

    int findCommunities();

    List<User> findLargest();
}
