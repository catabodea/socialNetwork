package repositories;

import domain.Entity;
import domain.validators.ValidationException;

import java.util.Optional;

public interface Repository<ID, E extends Entity<ID>> {
    Optional<E> findOne(ID id) throws IllegalArgumentException;

    Iterable<E> findAll();

    Optional<E> save(E entity) throws ValidationException, IllegalArgumentException;

    Optional<E> remove(ID id) throws IllegalArgumentException;

    Optional<E> modify(E entity) throws ValidationException, IllegalArgumentException;
}
