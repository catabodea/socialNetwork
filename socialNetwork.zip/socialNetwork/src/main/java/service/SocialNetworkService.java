package service;

import domain.Friendship;
import domain.Tuple;
import domain.User;
import repositories.Repository;
import repositories.UserRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class SocialNetworkService {
    private final UserRepository userRepository;
    private final Repository<Tuple<Long, Long>, Friendship> friendshipRepository;

    public SocialNetworkService(UserRepository userRepository, Repository<Tuple<Long, Long>, Friendship> friendshipRepository) {
        this.userRepository = userRepository;
        this.friendshipRepository = friendshipRepository;
    }

    public Optional<User> addUser(User user) {
        return userRepository.save(user);
    }

    public List<User> getUsers() {
        return StreamSupport.stream(userRepository.findAll().spliterator(), false).collect(Collectors.toList());
    }

    public Optional<User> deleteUser(Long id) {
        return userRepository.remove(id);
    }

    public Optional<User> updateUser(User user) {
        return userRepository.modify(user);
    }

    public Optional<User> getUser(Long id) {
        return userRepository.findOne(id);
    }

    public List<User> getFriends(Long id) {
        //noinspection OptionalGetWithoutIsPresent
        return new ArrayList<>(userRepository.findOne(id).get().getFriends());
    }

    public Optional<Friendship> addFriendship(Friendship friendship) {
        Optional<Friendship> optional = friendshipRepository.save(friendship);
        userRepository.addFriendship(friendship.getId().getLeft(), friendship.getId().getRight());
        return optional;
    }

    public List<Friendship> getFriendships() {
        return StreamSupport.stream(friendshipRepository.findAll().spliterator(), false).collect(Collectors.toList());
    }

    public Optional<Friendship> deleteFriendship(Long firstId, Long secondId) {
        Optional<Friendship> optional = friendshipRepository.remove(new Tuple<>(firstId, secondId));
        userRepository.removeFriendship(firstId, secondId);
        return optional;
    }

    public Optional<Friendship> getFriendship(Tuple<Long, Long> id) {
        return friendshipRepository.findOne(id);
    }

    private boolean friendListInitialized = false;
    private void initFriendsList() {
        if (friendListInitialized) {
            return;
        }
        for (Friendship friendship : friendshipRepository.findAll()) {
            userRepository.addFriendship(friendship.getId().getLeft(), friendship.getId().getRight());
        }
        friendListInitialized = true;
    }

    public int findNoCommunities() {
        initFriendsList();
        return userRepository.findCommunities();
    }

    public List<User> findLargestCommunity() {
        initFriendsList();
        return userRepository.findLargest();
    }
}
