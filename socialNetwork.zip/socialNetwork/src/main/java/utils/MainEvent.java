package utils;

public interface MainEvent {

}
