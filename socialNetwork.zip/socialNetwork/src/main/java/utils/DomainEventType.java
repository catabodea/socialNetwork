package utils;

public enum DomainEventType {
    ADD,
    UPDATE,
    DELETE
}
