package domain;

public enum Status {
    PENDING,
    APPROVED,
    REJECTED
}
