package domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

public class User extends Entity<Long> {
    private final String firstName;
    private final String lastName;
    private List<User> friendList;

    public User(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.friendList = new ArrayList<>();
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public List<User> getFriends() {
        return friendList;
    }

    public void setFriends(List<User> friendList) {
        this.friendList = friendList;
    }

    public void addFriend(User person) {
        friendList.add(person);
    }

    public void removeFriend(Long id) {
        Predicate<User> isFriend = x -> x.getId().equals(id);
        friendList.removeIf(isFriend);
    }

    @Override
    public String toString() {
        return this.getId().toString() + ',' + firstName + ',' + lastName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;
        User user = (User) o;
        return getFirstName().equals(user.getFirstName()) &&
                getLastName().equals(user.getLastName()) &&
                friendList.equals(user.friendList);
    }

    @Override
    public int hashCode() {
        return Objects.hash(getFirstName(), getLastName(), friendList);
    }
}
